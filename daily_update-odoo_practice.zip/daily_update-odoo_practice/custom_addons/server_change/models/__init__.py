
from . import res_partner
from . import schedular_action
