from odoo import models, fields


class exam(models.Model):
	"""
	Patient Details
	"""
	_name = 'exam.exam'
	# _inherit = 'res.partner'
	# _inherit = 'sale.order'

	# bdate = fields.Date(string='Birth Date')
