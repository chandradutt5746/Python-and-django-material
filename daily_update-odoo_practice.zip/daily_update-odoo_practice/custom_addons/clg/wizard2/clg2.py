from odoo import fields,models

class clg2(models.TransientModel):
    _name = 'wiz2.wiz2'

    salary = fields.Float()

    def printvalue(self):
        print('kdjas;hfd;lsfkjdas;flkj')
        