Employees = {'emp1':{'name':'Lisa', 'age':29, 'designation':'Programmer'},
                 'emp2':{'name':'Steve', 'age':45, 'designation':'Hr'}}
print(Employees)