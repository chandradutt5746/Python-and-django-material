import random

print(random.sample([i for i in range(100,200)],5))