"""Please write a program to generate all sentences where the subject is in
 ["I", "You"] and verb is in ["Play", "Love"] and the object is in"""


l1=["I", "You"]
l2=["Play", "Love"]

for i in l1:
    for j in l2:
        print(i,j)