# Write a program which are divisible by 7 and between a given range 0 and n.

n=90
l = [i for i in range(0,n+1) if(i%7==0)]
print(l)
