"""Please write a program to shuffle and print the list [3,6,7,8]."""


import random
l = [3,6,7,8]
print('b',l)
random.shuffle(l)
print('a',l)

# printing NONE
print(str(random.shuffle([3,6,7,8])))