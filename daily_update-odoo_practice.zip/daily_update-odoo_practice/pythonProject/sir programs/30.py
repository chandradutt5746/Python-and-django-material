"""Write a program to generate below Pattern:
*
* *
* * *
* * * *
* * * * *
* * * * * *
"""

for i in range(1,7):
    print('* ' *i,end='')
    print('\r')