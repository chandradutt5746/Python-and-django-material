"""
Write a Python program to iterate over dictionaries using for loops.
"""

d2 = {12: 144, 13: 169, 14: 196, 15: 225}

for i, j in d2.items():

    print(i, j)
