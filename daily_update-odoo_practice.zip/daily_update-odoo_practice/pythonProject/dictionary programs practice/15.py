"""
Write a Python program to get the maximum and minimum value in a dictionary.
"""

d = {4: 5, 8: 6, 1: 1, 2: 4, 5: 3, 3: 9}

print(max(d))

print(min(d))
