"""
Write a Python program to sort a given dictionary by key.
"""

d = {4: 5, 8: 6, 1: 1, 2: 4, 5: 3, 3: 9}

d = sorted(d.values())

print(d)
