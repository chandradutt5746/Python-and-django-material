"""
Write a Python program to sum all the items in a dictionary.
"""
"""
Write a Python program to multiply all the items in a dictionary.
"""

d = {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36}

print(sum(d.values()))

print()
