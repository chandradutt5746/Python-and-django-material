"""
Write a Python program to map two lists into a dictionary.
"""

l1 = [1, 2, 3, 4, 5]

l2 = [0, 9, 8, 7, 6]

d = dict(zip(l1, l2))

print(d)
