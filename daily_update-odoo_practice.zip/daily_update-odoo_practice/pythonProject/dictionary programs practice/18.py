d = {1: 2, 2: 3}

if not bool(d):
    print('empty')
else:
    print(d)
