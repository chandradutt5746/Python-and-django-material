d={}
if(len(d)==0):
    print(len(d),'empty')
else:
    print(len(d),'not')