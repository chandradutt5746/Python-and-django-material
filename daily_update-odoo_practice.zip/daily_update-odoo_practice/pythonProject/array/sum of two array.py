
arr1 = [1, 2, 3]
arr2 = [4, 5, 6]

# n = len(arr1)
# m = len(arr2)
sum = 0
# i=0
# while i < n:
# # for i in range(arr1):
# 	for j in range(arr2):
# 		sum = i + j
x = int("".join(str(i) for i in arr1))
y = int(''.join(str(j) for j in arr2))
print(type(x))
print(type(y))
print(x+y)

# for i in range(len(arr2)):
# print(sum)
