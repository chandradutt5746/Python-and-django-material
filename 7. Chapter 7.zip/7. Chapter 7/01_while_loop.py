i = 0
while i<10:
    print("Yes " + str(i))
    i = i + 1

print("Done")