a = "35fgrfg34"
a = int(a)
print(type(a))
print(a + 5)