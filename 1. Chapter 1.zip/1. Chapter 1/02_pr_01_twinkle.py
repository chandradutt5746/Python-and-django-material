'''
This problem is a solution of
Problem 1 of CodeWithHarry Practice Set!
'''
# This is also a comment just like the above line

print('''Twinkle, twinkle, little star,
How I wonder what you are!
Up above the world so high,
Like a diamond in the sky.''')
