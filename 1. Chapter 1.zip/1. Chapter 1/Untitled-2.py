
A = "dev"
b = "110"

print(A)
print(type(A))


greeting = "good morning"
name = "Dev"
print (type(name))


print (greeting + name)
print (name[1:2])




