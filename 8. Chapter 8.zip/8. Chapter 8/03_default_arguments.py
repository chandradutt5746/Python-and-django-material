def greet(name="Stranger"):
    print("Good Day, "+ name)
 

greet("Harry") 
greet()