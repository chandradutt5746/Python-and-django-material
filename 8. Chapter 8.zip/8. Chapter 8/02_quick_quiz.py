def greet(name):
    print("Good Day, "+ name)

def mySum(num1, num2):
    return num1 + num2

greet("Harry")
s = mySum(6, 32)
print(s)