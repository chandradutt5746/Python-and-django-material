from django.db import models

# Create your models here.
class student(models.Model):
    stuid = models.IntegerField()
    stuname = models.CharField(max_length=60)
    stuemail = models.EmailField(max_length=70)
    stupass = models.CharField(max_length=50)
    age = models.IntegerField(default=18)

    """
    def __str__(self):
        return str(self.stuid)

    def __str__(self):
        return self.stuname
    """
