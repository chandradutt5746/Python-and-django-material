from django.contrib import admin
from app.models import student
from .models import student
from .models import *

# Register your models here.
# admin.site.register(student)

"""
second method
class StudentAdmin(admin.ModelAdmin):
    list_display = ('stuid', 'stuname')

admin.site.register(student, StudentAdmin)
"""

# third method --> Register Model by Decorator
@admin.register(student)

class StudentAdmin(admin.ModelAdmin):
    list_display = ('stuid', 'stuname', 'stuemail', 'stupass', 'age')



