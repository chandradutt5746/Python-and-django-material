from functools import partial
from django.shortcuts import render
from rest_framework.serializers import Serializer
from .models import *
from .serializers import *
from rest_framework.response import Response
from rest_framework.decorators import api_view

# Create your views here.
@api_view()
def home(request):
    return Response({'status':200, "message":"Hello World"})


#  Retrieve the single student data
@api_view(['GET'])
def Home(request, pk):
    student_obj = Student.objects.get(id=pk)
    print("python data :", student_obj)
    serializer = StudentSerializer(student_obj)
    print("serializer: ", serializer)
    print("serializer data: ", serializer.data)
    return Response({'status':200, "payload":serializer.data})

#  Query set - All STudent Data
@api_view(['GET'])
def Home_List(request):
    student_obj = Student.objects.all()
    print("python data :", student_obj)
    serializer = StudentSerializer(student_obj, many=True)
    # print("serializer: ", serializer)
    # print("serializer data: ", serializer.data)
    return Response({'status':200, "payload":serializer.data})


# Post API
@api_view(['POST'])
def post_student(request):
    data = request.data 
    print("data")
    serializer = StudentSerializer(data=data)
    print("Serializer : ", serializer)
    if serializer.is_valid():
        # StudentSerializer.validate()
        serializer.save()
        

    else:
        return Response({'status':403, 'message':"Something went Wrong"})

    return Response({'status':200, "payload":data, 'message':"Data Saved Successfully"})

#  PUT API

@api_view(['PUT'])
def update_student(request, id):
    try:
        student_obj = Student.objects.get(id=id)
        serializer = StudentSerializer(student_obj, data=request.data)

        if not serializer.is_valid() :
            print(serializer.errors)
            return Response({'status':403, "errors": serializer.errors , 'message':"Something went Wrong"})

        serializer.save()
        return Response({'status':200, "payload":serializer.data, 'message':"Updated Successfully"})

    except Exception as e:
        return Response({'status':403, "message":"invalid id"})

#  PATCH API

@api_view(['PATCH'])
def update_student(request, id):
    try:
        student_obj = Student.objects.get(id=id)
        serializer = StudentSerializer(student_obj, data=request.data, partial=True)

        if not serializer.is_valid() :
            print(serializer.errors)
            return Response({'status':403, "errors": serializer.errors , 'message':"Something went Wrong"})

        serializer.save()
        return Response({'status':200, "payload":serializer.data, 'message':"Updated Successfully"})

    except Exception as e:
        return Response({'status':403, "message":"invalid id"})


# Delete Method 
@api_view(["DELETE"])
def delete_student(request, id):
    try:
        student_obj = Student.objects.get(id=id)
        student_obj.delete()

        return Response({'status':200, "payload":"Deleted Successfully"})

    except Exception as e:
        return Response({'status':403, "message":"invalid id"}) 