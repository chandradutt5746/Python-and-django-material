from django.shortcuts import render
from django.http.response import HttpResponse

# Create your views here.
def home(request):
    # return HttpResponse("<h1>Hello World</h1>")
    return render (request, 'add/home.html', {'name':'Sumit'})

def math(request):
    a = 25+65 
    return HttpResponse(a)

def learn_django(request):
    return render(request, 'add/django.html', {'course':'Django', 'name':'Rachel'})

def add(request):
    val1 = int(request.POST["num1"])
    val2 = int(request.POST["num2"])
    res = val1 + val2
    return render(request, 'add/result.html', {'result':res, "num1":val1, "num2":val2})

"""
Add emmet in the settings.json file which you will find in the below path :  
path : Preferences --> settings --> Extensions --> settings.json 
"emmet.triggerExpansionOnTab":true,
"files.associations": {"*html":"html"},
"""