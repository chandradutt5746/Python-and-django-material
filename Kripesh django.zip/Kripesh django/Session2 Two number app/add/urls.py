from django.contrib import admin
from django.urls import path
from .views import *
from . import views

urlpatterns = [
    # path('', views.home)
    path('', home, name='home'),
    path('math/', math, name="Math"),
    path('learndj/', learn_django, name="Django Page"),
    path('add', add, name='add')
]