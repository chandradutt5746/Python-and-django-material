from django.db.models import fields
from rest_framework import serializers 
from .models import * 

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = '__all__'

        # def validate(self, data) : 
        #     if data.age < 18 :
        #         raise serializers.ValidationError('Age must be greater than 18')
        #     else:
        #         return self.data
