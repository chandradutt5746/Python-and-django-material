from django.contrib import admin
from django.urls import path
from .views import *
from . import views

urlpatterns = [
    # path('', views.home)
    path('', home, name='home')
]