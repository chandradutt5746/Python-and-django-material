from django.shortcuts import render
from django.http.response import HttpResponse

# Create your views here.
def home(request):
    # return HttpResponse("<h1>Hello World</h1>")
    return render (request, 'add/home.html', {'name':'Sumit'})