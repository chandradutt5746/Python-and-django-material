from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import render

from enroll.models import User
from .forms import StudentRegistration

# Create your views here.
def add_show(request):
    if request.method == 'POST' :
        print("Post method")
        fm = StudentRegistration(request.POST)

    else:
        print("Get Method")
        fm = StudentRegistration()

    if fm.is_valid() :
        nm = fm.cleaned_data['Name']
        em = fm.cleaned_data['Email']
        pw = fm.cleaned_data['Password']
        reg = User(Name=nm, Email=em, Password = pw)
        reg.save()

    fm = StudentRegistration()
    stud = User.objects.all()

    return render(request, 'enroll/addandshow.html', {'form':fm, 'stu':stud})

def Delete_Data(request, id):
    if request.method == "POST":
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')

def Update_Data(request, id):
    if request.method == "POST":
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()

    else:
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(instance=pi)
    return render(request, 'enroll/updatestuents.html', {'form':fm})


"""
http methods
GET 
POST 
PUT/PATCH 
DELETE
"""


